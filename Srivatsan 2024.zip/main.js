window.addEventListener('resize', function() {
    location.reload();
    console.log(this.window.innerWidth)
});